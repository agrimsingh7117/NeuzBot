import React from 'react'

const Navbar = () => {
  return (
    <div>
      {/* Header */}
      <header className="flex flex-col md:flex-row justify-between items-center py-4 border-b border-gray-200 mb-6">
          <div className="flex items-center mb-4 md:mb-0">
            <h1 className="text-2xl font-bold text-gray-800">Neu<span className="text-red-500">zot</span></h1>
          </div>
          
          <nav className="flex flex-wrap justify-center gap-4 md:gap-6 mb-4 md:mb-0">
            <a href="/" className="text-gray-700 font-medium hover:text-blue-600 transition">Home</a>
            <a href="/party" className="text-gray-700 font-medium hover:text-blue-600 transition">Parties</a>
            <a href="/chatbot" className="text-gray-700 font-medium hover:text-blue-600 transition">Chatbot</a>
          </nav>
          
          <div className="flex gap-3">
            <button className="px-4 py-2 bg-blue-500 text-white rounded-md hover:bg-blue-600 transition">
              Subscribe
            </button>
          </div>
        </header>
    </div>
  )
}

export default Navbar
