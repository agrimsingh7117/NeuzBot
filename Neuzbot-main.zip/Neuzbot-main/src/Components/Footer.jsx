import React from 'react'

const Footer = () => {
  return (
    <div>
       {/* Footer */}
       <footer className="text-center py-8 mt-10 border-t border-gray-200 text-gray-500 text-sm">
          <p>© 2023 Neuzot - Indian Political News & Analytics. All rights reserved.</p>
          <div className="flex justify-center gap-4 mt-2">
            <a href="#" className="hover:text-blue-500">Terms</a>
            <a href="#" className="hover:text-blue-500">Privacy</a>
            <a href="#" className="hover:text-blue-500">About</a>
            <a href="#" className="hover:text-blue-500">Contact</a>
          </div>
        </footer>
    </div>
  )
}

export default Footer
