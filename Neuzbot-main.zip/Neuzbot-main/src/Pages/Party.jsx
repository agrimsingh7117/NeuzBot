import React from 'react';

const parties = [
  {
    id: 1,
    name: 'Bharatiya Janata Party (BJP)',
    logo: 'https://www.shutterstock.com/image-vector/rajkot-gujarat-india-10-disember-600nw-2400847291.jpg',
    leader: 'J. P. Nadda',
    alliance: 'NDA',
    founded: '1980',
  },
  {
    id: 2,
    name: 'Indian National Congress (INC)',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcS5h3ATWoZk6utuJo29dE4rmTMIa0UpMPc9hg&s',
    leader: 'Mallikarjun Kharge',
    alliance: 'INDIA',
    founded: '1885',
  },
  {
    id: 3,
    name: 'Aam Aadmi Party (AAP)',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcRzh79SQYJoG8_yY4Nrfu3jFixsuEotT9j4uw&s',
    leader: 'Arvind Kejriwal',
    alliance: 'INDIA',
    founded: '2012',
  },
  {
    id: 4,
    name: 'Trinamool Congress (TMC)',
    logo: 'https://imagesvs.oneindia.com/img/2019/03/tmc-logo-1553304690.jpg',
    leader: 'Mamata Banerjee',
    alliance: 'INDIA',
    founded: '1998',
  },
  {
    id: 5,
    name: 'Bahujan Samaj Party (BSP)',
    logo: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR-i8LnOreCsmJ38-meKdxxcC6xCltDFBGnRA&s',
    leader: 'Mayawati',
    alliance: 'Independent',
    founded: '1984',
  },
];

const Party = () => {
  return (
    <div className="min-h-screen bg-gradient-to-br from-white to-gray-100 px-4 py-10">
      <div className="max-w-6xl mx-auto">
        <h1 className="text-3xl sm:text-4xl font-bold mb-8 text-center text-gray-800">
          🇮🇳 Major Political Parties in India
        </h1>

        <div className="grid gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
          {parties.map(party => (
            <div
              key={party.id}
              className="bg-white rounded-2xl shadow-md hover:shadow-lg transition-all duration-300 p-6"
            >
              <div className="flex items-center space-x-4 mb-4">
                <img
                  src={party.logo}
                  alt={party.name}
                  className="w-16 h-16 object-contain rounded"
                />
                <div>
                  <h2 className="text-lg font-semibold">{party.name}</h2>
                  <p className="text-sm text-gray-500">Founded: {party.founded}</p>
                </div>
              </div>
              <div className="text-sm text-gray-700">
                <p><span className="font-medium">Leader:</span> {party.leader}</p>
                <p><span className="font-medium">Alliance:</span> {party.alliance}</p>
              </div>
            </div>
          ))}
        </div>

        <p className="mt-12 text-center text-sm text-gray-500">
          Data is based on public sources. Updated as of 2024.
        </p>
      </div>
    </div>
  );
};

export default Party;
