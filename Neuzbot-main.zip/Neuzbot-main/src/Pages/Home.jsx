import { useState, useEffect } from 'react';

const Home = () => {
  // State for stats data
  const [stats, setStats] = useState([
    { id: 1, title: 'UPI TRANSACTIONS TODAY', value: '₹4,832 Cr', change: '↑ 12.4% from yesterday', trend: 'positive' },
    { id: 2, title: 'ACTIVE POLITICAL CASES', value: '1,284', change: '↑ 3 new today', trend: 'negative' },
    { id: 3, title: 'NEXT ELECTION IN', value: '127 Days', change: 'Maharashtra', trend: 'neutral' },
    { id: 4, title: 'NEW POLITICAL NEWS', value: '247', change: 'Last updated 8 min ago', trend: 'positive' }
  ]);

  // State for breaking news
  const [breakingNews, setBreakingNews] = useState([
    {
      id: 1,
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcTEYEI5nU2R_FOfpmEBKHJW7TXrT7PKTdmtAw&s',
      source: 'The Hindu',
      time: '25 min ago',
      title: 'PM Modi addresses massive rally in Varanasi, outlines development roadmap',
      desc: 'Prime Minister Narendra Modi today unveiled several infrastructure projects worth ₹12,000 crore for his parliamentary constituency.',
      tag: 'BJP'
    },
    {
      id: 2,
      image: 'https://akm-img-a-in.tosshub.com/indiatoday/images/story/202403/rahul-gandhi-071857835-16x9_0.jpg?VersionId=5.mPErbqds6bIB0_qg5q1iy8noVwNhGY',
      source: 'Indian Express',
      time: '1 hour ago',
      title: 'Congress high command meets to finalize candidates for upcoming state elections',
      desc: 'The party is expected to announce its first list of candidates by tomorrow evening after internal surveys.',
      tag: 'Congress'
    },
    {
      id: 3,
      image: 'https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcQUNtYKOO4X_Xr6VRe6xDWjlz6LiaUqeT49Ig&s',
      source: 'Times of India',
      time: '2 hours ago',
      title: 'SC issues notice to Centre on plea challenging electoral bond scheme',
      desc: 'The petition claims the scheme violates citizens\' right to information about political funding.',
      tag: 'Judiciary'
    },


    {
      id: 3,
      image: 'https://th-i.thgim.com/public/incoming/wckpn6/article65359705.ece/alternates/FREE_1200/VJ25_CM_JAGAN%202.JPG',
      source: 'Times of India',
      time: '2 hours ago',
      title: 'Notice to Centre on plea challenging electoral bond scheme',
      desc: 'The petition claims the scheme violates citizens\' right to information about political funding.',
      tag: 'Judiciary'
    }
  ]);

  // State for trending topics
  const [trendingTopics, setTrendingTopics] = useState([
    { id: 1, name: '#LokSabhaElections2024', count: '24.5K' },
    { id: 2, name: '#FarmersProtest', count: '18.2K' },
    { id: 3, name: '#RahulInUSA', count: '15.7K' },
    { id: 4, name: '#NewEducationPolicy', count: '12.9K' },
    { id: 5, name: '#InflationRate', count: '10.3K' }
  ]);

  // State for live updates
  const [liveUpdates, setLiveUpdates] = useState([
    { id: 1, time: '2 mins ago', content: 'ECI announces dates for by-elections in 3 states' },
    { id: 2, time: '15 mins ago', content: 'Finance Minister to present interim budget tomorrow' },
    { id: 3, time: '32 mins ago', content: 'Supreme Court to hear plea on electoral bonds next week' },
    { id: 4, time: '1 hour ago', content: 'Rahul Gandhi concludes US tour, returns to Delhi' }
  ]);

  // Simulate data updates
  useEffect(() => {
    const interval = setInterval(() => {
      // Update stats randomly
      setStats(prevStats => prevStats.map(stat => {
        if (stat.id === 1) {
          const newValue = Math.floor(4000 + Math.random() * 1000);
          return { ...stat, value: `₹${newValue.toLocaleString()} Cr` };
        }
        if (stat.id === 4) {
          const newValue = Math.floor(200 + Math.random() * 100);
          return { ...stat, value: newValue.toString() };
        }
        return stat;
      }));

      // Rotate news items
      setBreakingNews(prevNews => {
        const [first, ...rest] = prevNews;
        return [...rest, first];
      });

      // Rotate trending topics
      setTrendingTopics(prevTopics => {
        const [first, ...rest] = prevTopics;
        return [...rest, first];
      });

      // Add new live update
      const newUpdate = {
        id: liveUpdates.length + 1,
        time: 'Just now',
        content: [
          'Defence Minister to visit Ladakh tomorrow',
          'New political alliance formed in Tamil Nadu',
          'Cabinet approves new infrastructure projects',
          'Opposition leaders meet to discuss strategy'
        ][Math.floor(Math.random() * 4)]
      };
      setLiveUpdates(prev => [newUpdate, ...prev.slice(0, 3)]);
    }, 10000); // Update every 10 seconds

    return () => clearInterval(interval);
  }, [liveUpdates.length]);

  return (
    <div className="bg-gray-50 min-h-screen font-sans">
      <div className="container mx-auto px-4 py-6">

        {/* Main Content */}
        <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
          {/* Left Column (3/4 width) */}
          <div className="lg:col-span-3 space-y-6">
            {/* Stats Cards */}
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {stats.map(stat => (
                <div key={stat.id} className="bg-white p-5 rounded-lg shadow-sm hover:shadow-md transition">
                  <h3 className="text-xs text-gray-500 mb-2 uppercase">{stat.title}</h3>
                  <p className="text-2xl font-semibold mb-1">{stat.value}</p>
                  <p className={`text-xs flex items-center ${
                    stat.trend === 'positive' ? 'text-green-500' : 
                    stat.trend === 'negative' ? 'text-red-500' : 'text-gray-500'
                  }`}>
                    {stat.change}
                  </p>
                </div>
              ))}
            </div>

            {/* Breaking News */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-5">
                <h2 className="text-xl font-semibold">Breaking Political News</h2>
                <a href="#" className="text-blue-500 text-sm hover:underline">View All →</a>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                {breakingNews.map(news => (
                  <div key={news.id} className="rounded-lg overflow-hidden shadow-sm hover:shadow-md transition">
                    <img src={news.image} alt={news.title} className="w-full h-40 object-cover" />
                    <div className="p-4">
                      <div className="flex justify-between text-xs text-gray-500 mb-2">
                        <span>{news.source}</span>
                        <span>{news.time}</span>
                      </div>
                      <h3 className="font-medium mb-2">{news.title}</h3>
                      <p className="text-sm text-gray-600 mb-3">{news.desc}</p>
                      <span className="inline-block px-2 py-1 bg-blue-50 text-blue-500 text-xs rounded">
                        {news.tag}
                      </span>
                    </div>
                  </div>
                ))}
              </div>
              
              <p className="text-right text-xs text-gray-500 mt-3 animate-pulse">
                Live updates refresh every 2 minutes
              </p>
            </div>

            {/* Election Watch */}
            <div className="bg-white p-6 rounded-lg shadow-sm">
              <div className="flex justify-between items-center mb-5">
                <h2 className="text-xl font-semibold">Election Watch 2024</h2>
                <a href="#" className="text-blue-500 text-sm hover:underline">View All →</a>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-5">
                <div className="rounded-lg overflow-hidden shadow-sm hover:shadow-md transition">
                  <img src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcR9NJQLOOenqj5rK7OdjB67jvyyGjGpVLVMng&s" alt="Election" className="w-full h-40 object-cover" />
                  <div className="p-4">
                    <div className="flex justify-between text-xs text-gray-500 mb-2">
                      <span>NDTV</span>
                      <span>45 min ago</span>
                    </div>
                    <h3 className="font-medium mb-2">BJP launches 'Vijay Sankalp Yatra' in 5 states ahead of elections</h3>
                    <p className="text-sm text-gray-600 mb-3">The campaign will cover 150 constituencies with top leaders participating in roadshows.</p>
                    <span className="inline-block px-2 py-1 bg-blue-50 text-blue-500 text-xs rounded">
                      Campaign
                    </span>
                  </div>
                </div>
                
                <div className="rounded-lg overflow-hidden shadow-sm hover:shadow-md transition">
                  <img src="https://s7ap1.scene7.com/is/image/incredibleindia/mysore-palace-karnataka-state-hero?qlt=82&ts=1726723003730" alt="Poll" className="w-full h-40 object-cover" />
                  <div className="p-4">
                    <div className="flex justify-between text-xs text-gray-500 mb-2">
                      <span>India Today</span>
                      <span>3 hours ago</span>
                    </div>
                    <h3 className="font-medium mb-2">Latest opinion poll gives NDA edge in Karnataka but shows close contest</h3>
                    <p className="text-sm text-gray-600 mb-3">The survey predicts 45% vote share for NDA compared to 41% for UPA in the state.</p>
                    <span className="inline-block px-2 py-1 bg-blue-50 text-blue-500 text-xs rounded">
                      Poll
                    </span>
                  </div>
                </div>
                
                <div className="rounded-lg overflow-hidden shadow-sm hover:shadow-md transition">
                  <img src="https://th-i.thgim.com/public/incoming/qzrfvw/article68170761.ece/alternates/FREE_1200/iStock-2148922406.jpg" alt="Voters" className="w-full h-40 object-cover" />
                  <div className="p-4">
                    <div className="flex justify-between text-xs text-gray-500 mb-2">
                      <span>The Wire</span>
                      <span>1 hour ago</span>
                    </div>
                    <h3 className="font-medium mb-2">Voter registration crosses 80% mark in 5 key states</h3>
                    <p className="text-sm text-gray-600 mb-3">ECI reports highest registration among 18-25 age group in southern states.</p>
                    <span className="inline-block px-2 py-1 bg-blue-50 text-blue-500 text-xs rounded">
                      Voters
                    </span>
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Right Sidebar (1/4 width) */}
          <div className="space-y-6">
            {/* Trending Topics */}
            <div className="bg-white p-5 rounded-lg shadow-sm">
              <h2 className="text-lg font-semibold mb-4">Trending Topics</h2>
              <div className="space-y-3">
                {trendingTopics.map((topic, index) => (
                  <div key={topic.id} className="flex items-center py-2 border-b border-gray-100">
                    <span className="text-blue-500 font-medium w-6">{index + 1}</span>
                    <span className="flex-1 text-sm font-medium">{topic.name}</span>
                    <span className="text-xs text-gray-500">{topic.count}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Live Updates */}
            <div className="bg-white p-5 rounded-lg shadow-sm">
              <h2 className="text-lg font-semibold mb-4">Live Updates</h2>
              <div className="space-y-4">
                {liveUpdates.map(update => (
                  <div key={update.id} className="pb-3 border-b border-gray-100 last:border-0">
                    <p className="text-xs text-gray-500 mb-1">{update.time}</p>
                    <p className="text-sm">{update.content}</p>
                  </div>
                ))}
              </div>
            </div>

            {/* Opinion Poll */}
            <div className="bg-white p-5 rounded-lg shadow-sm">
              <h2 className="text-lg font-semibold mb-4">Opinion Poll</h2>
              <div className="space-y-5">
                <div>
                  <h3 className="text-sm font-medium mb-3">Who will win the 2024 General Elections?</h3>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>NDA (BJP+Allies)</span>
                        <span>48%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '48%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>UPA (Congress+Allies)</span>
                        <span>35%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-green-500 rounded-full" style={{ width: '35%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Others/Regional Parties</span>
                        <span>17%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-yellow-500 rounded-full" style={{ width: '17%' }}></div>
                      </div>
                    </div>
                  </div>
                  <p className="text-xs text-gray-500 mt-3">Survey of 25,000 voters across 20 states</p>
                </div>

                <div>
                  <h3 className="text-sm font-medium mb-3">Preferred PM Candidate?</h3>
                  <div className="space-y-2">
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Narendra Modi</span>
                        <span>52%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-blue-500 rounded-full" style={{ width: '52%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Rahul Gandhi</span>
                        <span>28%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-green-500 rounded-full" style={{ width: '28%' }}></div>
                      </div>
                    </div>
                    <div>
                      <div className="flex justify-between text-xs mb-1">
                        <span>Others/Undecided</span>
                        <span>20%</span>
                      </div>
                      <div className="h-2 bg-gray-200 rounded-full overflow-hidden">
                        <div className="h-full bg-yellow-500 rounded-full" style={{ width: '20%' }}></div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Home;