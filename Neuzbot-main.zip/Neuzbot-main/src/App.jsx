import React from 'react'
import { BrowserRouter ,Routes,Route} from 'react-router-dom';
import Navbar from './Components/Navbar';
import Footer from './Components/Footer';
import Home from './Pages/Home';
import Party from './Pages/Party';
import Chatbot from './Pages/Chatbox'


const App = () => {
  return (
<div>
    <Navbar/>
       <BrowserRouter>
          <Routes>
              <Route path='/' element={<Home/>}></Route>
              <Route path='/party' element={<Party/>}></Route>
              <Route path='/chatbot' element={<Chatbot/>}></Route>
         </Routes>
       </BrowserRouter>
   <Footer/>
   </div>
  )
}

export default App
